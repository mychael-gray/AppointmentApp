package models;

import javafx.scene.control.Alert;

import java.sql.*;

public class Customer {


    private  Integer customerId;
    private String name;
    private String address;
    private String postalCode;
    private String phoneNumber;
    private String country;
    private  Integer divisionId;
    private String division;
    public static Connection conn;


    /**
     Constructor for  Customer class.
     Initializes the instance variables with the values passed in as parameters.
     @param customerId Unique identifier for the customer
     @param name Name of the customer
     @param address Address of the customer
     @param postalCode Postal code of the customer's address
     @param phoneNumber Phone number of the customer
     @param country Country of the customer
     @param divisionId Unique identifier for the customer's division
     */
    public Customer(Integer customerId, String name, String address, String postalCode, String phoneNumber, String country, Integer divisionId) {
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.postalCode = postalCode;
        this.phoneNumber = phoneNumber;
        this.country = country;
        this.divisionId = divisionId;
        this.division = division;
    }


    /**
     *getters and setters for the parameters
     */
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public  Integer getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(Integer divisionId) {
        this.divisionId = divisionId;
    }

    /**
     *method to convert values in the Division_ID field to the associated value in the Division field.
     * @param divisionId is the input and is used in the program when populating the appointments tableview
     */
    public static String divisionIdToDivision(String divisionId, Connection conn) throws SQLException {
        String division = "";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Division_ID, Division FROM first_level_divisions");
        while (rs.next()) {
            String divId = rs.getString("Division_ID");
            if (divisionId.equals(divId)) {
                division = rs.getString("Division");
                System.out.println(division);
                break;
            }
        }
        rs.close();
        stmt.close();


        return division;
    }
    /**
     *method to convert values in the Division field to the associated value in the Division_ID field.
     * @param division is the input and is used in the program when populating the appointments tableview
     */
    public static Integer divisionToDivisionId(String division, Connection conn) throws SQLException {
        Integer divisionId = 0;
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Division_ID, Division FROM first_level_divisions");
        while (rs.next()) {
            String div = rs.getString("Division");
            if (division.equals(div)) {
                divisionId = rs.getInt("Division_ID");
                break;
            }
        }
        rs.close();
        stmt.close();
        if (division == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning invalid input");
            alert.setHeaderText("Please select a state or province.");
            alert.showAndWait();

        }
        return divisionId;
    }

    /**
     *method to check if a customer exists. This method is called when adding appointments to ensure the associated customer exists
     * @param customer_ID is the uniquie id for the customer and is used for customer validation.
     */
    public static boolean customerDoesNotExist(int customer_ID, Connection conn) {
        try {
            String query = "SELECT Customer_ID FROM customers";
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery(query);

            while (resultSet.next()) {
                if (resultSet.getInt("Customer_ID") == customer_ID) {
                    return false;
                }
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Error occurred while querying the customers table: " + e.getMessage());
            return false;
        }
    }

    /**
     *method to convert check if customer has current appointments before they can be deleted
     * @param customer_ID
     */
    public static boolean customerHasApps(Integer customer_ID,Connection conn) {
        try {
            String query = "SELECT appointments.Appointment_ID, appointments.Customer_ID, customers.Customer_ID FROM appointments INNER JOIN customers ON appointments.Customer_ID = customers.Customer_ID;";
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery(query);

            while (resultSet.next()) {
                if (resultSet.getInt("Customer_ID") == customer_ID) {
                    return true;
                }
            }
            return false;
        } catch (SQLException e) {
            System.out.println("Error occurred while querying the customers table: " + e.getMessage());
            return false;
        }
    }


    /**
     *method to add customers to the database
     * @param customer takes the customer object and add those parameters to the database
     */
    public static void addToCustomerDB(Customer customer, Connection conn) throws SQLException {
        String sql = "INSERT INTO customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (?,?,?,?,?,?)";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, customer.getCustomerId());
        statement.setString(2, customer.getName());
        statement.setString(3, customer.getAddress());
        statement.setString(4, customer.getPostalCode());
        statement.setString(5, customer.getPhoneNumber());
        statement.setInt(6, customer.getDivisionId());

        statement.executeUpdate();
    }
    public void setDivision(String division) {
        this.division = division;
    }

    public String getDivision() {
        return division;
    }

}

















