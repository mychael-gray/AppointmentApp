package models;

import helper.JBDC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;


public class Appointments {
    private ObservableList<String> contactNames = FXCollections.observableArrayList();
    private  ComboBox<String> appointmentsContactnameCombo;
        private  Integer Appointment_ID;
        private String Title;
        private String Description;
        private String Location;
        public String Contact_Name;
        private String Type;
        public LocalDateTime Start;
        public LocalDateTime End;
        private Integer Customer_ID;
        private Integer User_ID;
        private Integer Contact_ID;
        private static LocalDateTime convertedEST;
        private String monthName;

    public static Connection conn = JBDC.conn;

    /**
     * Constructor for the Appointments class.
     *
     * @param Appointment_ID the ID of the appointment
     * @param Title the title of the appointment
     * @param Description the description of the appointment
     * @param Location the location of the appointment
     * @param Contact_Name the contact name of the appointment
     * @param Type the type of the appointment
     * @param Start the start time of the appointment
     * @param End the end time of the appointment
     * @param Customer_ID the customer ID associated with the appointment
     * @param User_ID the user ID associated with the appointment
     */
        public Appointments(Integer Appointment_ID, String Title, String Description, String Location, String Contact_Name, String Type, LocalDateTime Start, LocalDateTime End, Integer Customer_ID, Integer User_ID) {
            this.Appointment_ID = Appointment_ID;
            this.Title = Title;
            this.Description = Description;
            this.Location = Location;
            this.Contact_Name = Contact_Name;
            this.Type = Type;
            this.Start = Start;
            this.End = End;
            this.Customer_ID = Customer_ID;
            this.User_ID = User_ID;
        }




    /**
     *Overloaded constructor with only two parameters for use with  @FXML
     *     void reportMonth(ActionEvent event) method.
     * @param Type the type of the appointment
     * @param Start the start time of the appointment

     */
    public Appointments(LocalDateTime Start, String Type) {
        this.Start = Start;
        this.Type = Type;
        this.monthName = getMonthName(Start);
    }

    /**
     *Empty Constructor
     */
    public Appointments() {

    }

    public Appointments(Integer Appointment_ID, String Title, String Type, String Description, LocalDateTime Start, LocalDateTime End, Integer Customer_ID, Integer Contact_ID, String Contact_Name) {
        this.Appointment_ID = Appointment_ID;
        this.Title = Title;
        this.Description = Description;
        this.Contact_Name = Contact_Name;
        this.Type = Type;
        this.Start = Start;
        this.End = End;
        this.Customer_ID = Customer_ID;

    }

    /**
     *Getters and Setters for Constructor parameters
     */
    public int getAppointment_ID() {
            return Appointment_ID;
        }

        public void setAppointment_ID(Integer Appointment_ID) {
            this.Appointment_ID = Appointment_ID;
        }

        public String getTitle() {
            return Title;
        }

        public void setTitle(String Title) {
            this.Title = Title;
        }

        public String getDescription() {
            return Description;
        }

        public void setDescription(String Description) {
            this.Description = Description;
        }

        public String getLocation() {
            return Location;
        }

        public void setLocation(String Location) {
            this.Location = Location;
        }

        public String getContact_Name() {
            return Contact_Name;
        }

        public void setContact_Name(String Contact_Name) {
            this.Contact_Name = Contact_Name;
        }

        public String getType() {
            return Type;
        }

        public void setType(String Type) {
            this.Type = Type;
        }

        public LocalDateTime getStart() {
            return Start  ;
        }
    public Integer getContact_ID() {
        return Contact_ID;
    }

    public void setContact_ID(Integer contact_ID) {
        Contact_ID = contact_ID;
    }

        public void setStart(LocalDateTime Start) {
            this.Start = Start;
        }

        public LocalDateTime getEnd() {
            return End;
        }

        public void setEnd(LocalDateTime End) {
            this.End = End;
        }

        public int getCustomer_ID() {
            return Customer_ID;
        }

        public void setCustomer_ID(Integer Customer_ID) {
            this.Customer_ID = Customer_ID;
        }

        public int getUser_ID() {
            return User_ID;
        }

        public void setUser_ID(Integer User_ID) {
            this.User_ID = User_ID;
        }



    public Appointments(ComboBox<String> appointmentsContactnameCombo) {
        this.appointmentsContactnameCombo = appointmentsContactnameCombo;
    }

    /**
     *method to populate appointmentsContactnameCombo with observablelist contactNames
     */
    public  void addContactNames() {
        contactNames.add("Anika Costa");
        contactNames.add("Daniel Garcia");
        contactNames.add("Li Lee");
        appointmentsContactnameCombo.setItems(contactNames);
    }

    /**
     * This method converts the Contact-Name field to Contact_ID.
     *
     * @param Contact_Name the contact name to be converted to Contact_ID
     * @param conn the connection object to the database
     * @return the Contact_ID that corresponds to the input Contact_Name
     * @throws SQLException if there is an error with the SQL statement
     */
    public static Integer contactNametoID(String Contact_Name, Connection conn) throws SQLException {
        Integer Contact_ID = 0;
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Contact_ID, Contact_Name FROM contacts");
        while (rs.next()) {
            String conName = rs.getString("Contact_Name");
            if (Contact_Name.equals(conName)) {
                Contact_ID= rs.getInt("Contact_ID");
                break;
            }
        }
        rs.close();
        stmt.close();

        return Contact_ID;
    }
    /**
     *method to generate appointmentID. Selects the larges value in the Appointment_ID field ad assigns that value plus one to the new added value
     * @param  conn
     */
    public Integer generateAppointmentId(Connection conn) throws SQLException {

        PreparedStatement statement = conn.prepareStatement("SELECT MAX(Appointment_ID) FROM appointments", Statement.RETURN_GENERATED_KEYS);
        ResultSet resultSet = statement.executeQuery();
        resultSet.next();
        this.Appointment_ID = resultSet.getInt(1) + 1;
        return Appointment_ID;
    }
    /**
     *method to convert a LocalDateTime object to UTC.
     * @param localDateTime
     */
    public static LocalDateTime toUTC(LocalDateTime localDateTime) {
        ZoneId systemDefault = ZoneId.systemDefault();
        ZonedDateTime zonedDateTime = localDateTime.atZone(systemDefault);
        localDateTime = zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime();
        return localDateTime;
    }

    /**
     *method to take a LocalDateTime object and determine if that time is during business hours based on EST.
     * @param localDateTime is a parameter that has already been converted to EST
     */
    public static boolean isWithinBusinessHours(LocalDateTime localDateTime) {
        int hour = localDateTime.getHour();
        if (hour < 8 || hour >= 22) {
            return false;
        }
        return true;
    }


    /**
     *method to convert a LocalDateTime object to EST
     */
    public static LocalDateTime toEST(LocalDateTime localDateTime) {
            ZoneId systemDefault = ZoneId.systemDefault();
            ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, systemDefault);
            ZoneId est = ZoneId.of("America/New_York");
            ZonedDateTime estDateTime = zonedDateTime.withZoneSameInstant(est);
            convertedEST = estDateTime.toLocalDateTime();
            return convertedEST;
        }

    /**
     *method to convert localtime to UTC
     */
        public static LocalDateTime toLocal(LocalDateTime utcTime) {
        ZoneId userZone = ZoneId.systemDefault();
        ZonedDateTime zonedUTC = utcTime.atZone(ZoneOffset.UTC);
        ZonedDateTime zonedLocal = zonedUTC.withZoneSameInstant(userZone);
        return zonedLocal.toLocalDateTime();
    }


    /**
     *method to add an appointment to the Database.
     */
    public static void addAppointmentToDB(Appointments appointment, Connection conn) throws SQLException {
        appointment.generateAppointmentId(conn);
        String sql = "INSERT INTO appointments(Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID) VALUES (?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, appointment.getAppointment_ID());
        statement.setString(2, appointment.getTitle());
        statement.setString(3, appointment.getDescription());
        statement.setString(4, appointment.getLocation());
        statement.setString(5, appointment.getType());
        LocalDateTime convertedStartTime = toUTC(appointment.getStart());
        statement.setObject(6, convertedStartTime);
        LocalDateTime convertedEndTime = toUTC(appointment.getEnd());
        statement.setObject(7, convertedEndTime);
        statement.setInt(8, appointment.getCustomer_ID());
        statement.setInt(9, appointment.getUser_ID());
        statement.setInt(10, appointment.getContact_ID());
        statement.executeUpdate();
    }



    /**
     *method to determin if the appointment that the use is attempting to ass to the database conflicts with existing customer appointments.
     * @param customer_ID is the field by which the table is searched for unique customer appointments at that time. Stored in UTC but displayed in LocalTime.
     */
    public static boolean appointmentOverlap(LocalDateTime start, LocalDateTime end, int customer_ID) {
        try {
            String query = "SELECT * FROM appointments WHERE Customer_ID = ? AND ((Start >= ? AND Start < ?) OR (End > ? AND End <= ?) OR (Start <= ? AND End >= ?))";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, customer_ID);
            statement.setObject(2, start);
            statement.setObject(3, end);
            statement.setObject(4, start);
            statement.setObject(5, end);
            statement.setObject(6, start);
            statement.setObject(7, end);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static String getMonthName(LocalDateTime Start) {
        return Start.getMonth().toString();
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

}








