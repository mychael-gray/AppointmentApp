package controllers;


import helper.JBDC;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import models.Appointments;
import models.Customer;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.function.Supplier;


public class AppointmentsController implements Initializable {
    @FXML
    private Button appointmentsBackButton;

    @FXML
    private ToggleGroup weekOrMonth;
    @FXML
    private TableColumn<Appointments, Integer> AppointmentIdCol;

    @FXML
    private TableView<Appointments> appointmentsTableView;

    @FXML
    private TableColumn<Appointments, String> appointmentDescriptionCol;

    @FXML
    private TableColumn<Appointments, String> appointmentLocationCol;

    @FXML
    private TableColumn<Appointments, String> appointmentTitleCol;

    @FXML
    private TableColumn<Appointments, Integer> appointmentUserIdCol;

    @FXML
    private TableColumn<Appointments, String> appointmentsContactsCol;

    @FXML
    private TableColumn<Appointments, Integer> appointmentsCustomerIdCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> appointmentsEndDateCol;

    @FXML
    private RadioButton appointmentsMonthlyRadio;

    @FXML
    private TableColumn<Appointments, LocalDateTime> appointmentsStartDateCol;

    @FXML
    private TableColumn<Appointments, String> appointmentsTypeCol;

    @FXML
    private RadioButton appointmentsWeeklyRadio;

    @FXML
    private Button clearTableButton;

    @FXML
    void onClickClearTable(ActionEvent event) {
        appointments.clear();
        appointmentsTableView.setItems(appointments);
    }

    @FXML
    void onClickNavBack(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/AppointmentsorCustomers.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * when the radio button is selected a LocalDateTime object is created of the current moment than a month is added to that object. Any appointment objects with Start parameters within a month of that moment is displayed in the tableview.
     */
    @FXML
    void onSelectDisplayMonthly(ActionEvent event) {
        appointments.clear();

        try {

            LocalDateTime now = LocalDateTime.now();
            Timestamp startDate = Timestamp.valueOf(now);
            String start = startDate.toString();
            Timestamp endDate = Timestamp.valueOf(now.plusMonths(1));
            String end = endDate.toString();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID WHERE Start BETWEEN ? AND ?;");
            stmt.setString(1, start);
            stmt.setString(2, end);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                int Appointment_ID = resultSet.getInt("Appointment_ID");
                String Title = resultSet.getString("Title");
                String Description = resultSet.getString("Description");
                String Location = resultSet.getString("Location");
                String Contact_Name = resultSet.getString("Contact_Name");
                String Type = resultSet.getString("Type");
                LocalDateTime Start = resultSet.getObject("Start", LocalDateTime.class);
                LocalDateTime StartMonthLocal = Appointments.toLocal(Start);
                LocalDateTime End = resultSet.getObject("End", LocalDateTime.class);
                LocalDateTime EndMonthLocal = Appointments.toLocal(End);
                int Customer_ID = resultSet.getInt("Customer_ID");
                int User_ID = resultSet.getInt("User_ID");
                Appointments appointment = new Appointments(Appointment_ID, Title, Description, Location, Contact_Name, Type, StartMonthLocal, EndMonthLocal, Customer_ID, User_ID);

                appointments.add(appointment);
            }

            appointmentsTableView.setItems(appointments);

            AppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
            appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
            appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
            appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
            appointmentsContactsCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
            appointmentsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
            appointmentsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
            appointmentsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("End"));
            appointmentsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
            appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * when the radio button is selected a LocalDateTime object is created of the current moment than a week is added to that object. Any appointment objects with Start paremeters within a week of that moment is displayed in the tableview.
     */
    @FXML
    void onSelectDisplayWeekly(ActionEvent event) {
        appointments.clear();
        try {


            LocalDateTime nowWeek = LocalDateTime.now();
            Timestamp startWeekDate = Timestamp.valueOf(nowWeek);
            String startWeek = startWeekDate.toString();
            Timestamp endWeekDate = Timestamp.valueOf(nowWeek.plusWeeks(1));
            String endWeek = endWeekDate.toString();

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID WHERE Start BETWEEN ? AND ?;");
            stmt.setString(1, startWeek);
            stmt.setString(2, endWeek);
            ResultSet resultset = stmt.executeQuery();


            while (resultset.next()) {
                int Appointment_ID = resultset.getInt("Appointment_ID");
                String Title = resultset.getString("Title");
                String Description = resultset.getString("Description");
                String Location = resultset.getString("Location");
                String Contact_Name = resultset.getString("Contact_Name");
                String Type = resultset.getString("Type");
                LocalDateTime Start = resultset.getObject("Start", LocalDateTime.class);
                LocalDateTime StartWeekLocal = Appointments.toLocal(Start);
                LocalDateTime End = resultset.getObject("End", LocalDateTime.class);
                LocalDateTime EndWeekLocal = Appointments.toLocal(End);
                int Customer_ID = resultset.getInt("Customer_ID");
                int User_ID = resultset.getInt("User_ID");


                Appointments appointment = new Appointments(Appointment_ID, Title, Description, Location, Contact_Name, Type, StartWeekLocal, EndWeekLocal, Customer_ID, User_ID);

                appointments.add(appointment);
            }

            appointmentsTableView.setItems(appointments);

            AppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
            appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
            appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
            appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
            appointmentsContactsCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
            appointmentsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
            appointmentsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
            appointmentsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("End"));
            appointmentsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
            appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private Button appointmentsAddButton;

    @FXML
    private TextField appointmentsAppIdTF;

    @FXML
    private ComboBox<String> appointmentsContactnameCombo;

    @FXML
    private Label appointmentsCustomerIdLabel;

    @FXML
    private TextField appointmentsCustomerIdTF;

    @FXML
    private Button appointmentsDeleteButton;

    @FXML
    private Label appointmentsDescriptionLabel;

    @FXML
    private TextField appointmentsDescriptionTF;

    @FXML
    private Label appointmentsEndDateLabel;

    @FXML
    private TextField appointmentsEndDateTF;

    @FXML
    private Label appointmentsIdLabel;

    @FXML
    private Label appointmentsLocationLabel;

    @FXML
    private TextField appointmentsLocationTF;

    @FXML
    private Label appointmentsStartDateLabel;

    @FXML
    private TextField appointmentsStartDateTF;

    @FXML
    private TextField appointmentsTitleTF;

    @FXML
    private Label appointmentsTypeLabel;

    @FXML
    private TextField appointmentsTypeTF;

    @FXML
    private Button appointmentsUpdateButton;

    @FXML
    private Label appointmentsUserIdLabel;

    @FXML
    private TextField appointmentsUserIdTF;

    @FXML
    private Button appointmentsViewButton;

    @FXML
    private Label appointmetsTitleLabel;

    /**
     * Data is entered into the textfields on the form and is then added to the tableview as well as the mysql database.
     * Exception handling methods check if the added appointments overlap with other appointments and are within business hours
     */
    @FXML
    void onClickAddAppointments(ActionEvent event) throws IOException, SQLException {


        Appointments appointment = new Appointments();
        Integer Appointment_ID = appointment.generateAppointmentId(conn);
        String Title = appointmentsTitleTF.getText();
        String Description = appointmentsDescriptionTF.getText();
        String Location = appointmentsLocationTF.getText();
        String Contact_Name = appointmentsContactnameCombo.getSelectionModel().getSelectedItem();
        String Type = appointmentsTypeTF.getText();
        LocalDateTime Start = LocalDateTime.parse(appointmentsStartDateTF.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        LocalDateTime End = LocalDateTime.parse(appointmentsEndDateTF.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        Integer Customer_ID = Integer.valueOf(appointmentsCustomerIdTF.getText());
        Integer User_ID = Integer.valueOf(appointmentsUserIdTF.getText());
        Integer Contact_ID = Appointments.contactNametoID(Contact_Name, conn);
        LocalDateTime startToUTC = Appointments.toUTC(Start);
        LocalDateTime endToUTC = Appointments.toUTC(End);

        if (Customer.customerDoesNotExist(Customer_ID, conn)) {

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Customer does not exist");
            alert.setHeaderText(null);
            alert.setContentText("Please choose an existing customer.");
            alert.showAndWait();
        } else if (!Appointments.isWithinBusinessHours(Appointments.toEST(Start)) || !Appointments.isWithinBusinessHours(Appointments.toEST(End))) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Outside Business Hours");
            alert.setHeaderText(null);
            alert.setContentText("Please schedule appointment between 8:00 AM and 10:00 PM Eastern Standard Time.");
            alert.showAndWait();
        } else if (Appointments.appointmentOverlap(startToUTC, endToUTC, Customer_ID)) {

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Customer Overlap");
            alert.setContentText("This customer already has an appointment at that time.");
            alert.showAndWait();
        } else {

            Appointments addAppointment = new Appointments(Appointment_ID, Title, Description, Location, Contact_Name, Type, Start, End, Customer_ID, User_ID);
            addAppointment.setContact_ID(Contact_ID);
            appointments.add(addAppointment);

            appointmentsTableView.setItems(appointments);
            AppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
            appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
            appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
            appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
            appointmentsContactsCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
            appointmentsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
            appointmentsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
            appointmentsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("End"));
            appointmentsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
            appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));

            Appointments.addAppointmentToDB(addAppointment, conn);
        }
    }

    /**
     * the appointment object selected in the tableview is deleted from the tableview as well as well as the database
     */
    @FXML
    void onClickDeleteAppointment(ActionEvent event) {
        Appointments selectedAppointment = appointmentsTableView.getSelectionModel().getSelectedItem();
        String appointmentType = "";
        Integer appointmentID = 0;

        appointments.remove(selectedAppointment);
        appointmentsTableView.setItems(appointments);
        try {
            PreparedStatement statement = conn.prepareStatement("DELETE FROM appointments WHERE Appointment_ID = ?");
            statement.setInt(1, selectedAppointment.getAppointment_ID());
            appointmentID = selectedAppointment.getAppointment_ID();
            appointmentType = selectedAppointment.getType();
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("You have deleted an appointment with appointment ID = " + appointmentID + " and Type = " + appointmentType + ".");
        alert.showAndWait();
    }


    /**
     * The data from the selected tableview object is inserted to the appropiate textfields or combobxes. This method does not update the data. It simply loads the data to the correct space for editing.
     */
    @FXML
    void onClickUpdateAppointment(ActionEvent event) {
        Appointments selectedAppointment = appointmentsTableView.getSelectionModel().getSelectedItem();
        LocalDateTime Start = selectedAppointment.getStart();
        LocalDateTime End = selectedAppointment.getEnd();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String startString = Start.format(formatter);
        String endString = End.format(formatter);


        appointmentsAppIdTF.setText(String.valueOf(selectedAppointment.getAppointment_ID()));
        appointmentsTitleTF.setText(selectedAppointment.getTitle());
        appointmentsDescriptionTF.setText(selectedAppointment.getDescription());
        appointmentsLocationTF.setText(selectedAppointment.getLocation());
        appointmentsContactnameCombo.getSelectionModel().select(selectedAppointment.getContact_Name());
        appointmentsTypeTF.setText(selectedAppointment.getType());
        appointmentsStartDateTF.setText(startString);
        appointmentsEndDateTF.setText(endString);
        appointmentsCustomerIdTF.setText(String.valueOf(selectedAppointment.getCustomer_ID()));
        appointmentsUserIdTF.setText(String.valueOf(selectedAppointment.getUser_ID()));


    }


    /**
     * Medthod to update appointment object in the tableviewnd database
     * Exception handling is provided by the appoitmentsOverlap and isBusinessHours method
     */
    @FXML
    void onClickSaveUpdateAppointment(ActionEvent event) throws SQLException {

        Appointments selectedAppointment = appointmentsTableView.getSelectionModel().getSelectedItem();
        String Contact_Name = appointmentsContactnameCombo.getSelectionModel().getSelectedItem();
        Integer Contact_ID = Appointments.contactNametoID(Contact_Name, conn);
        selectedAppointment.setContact_ID(Contact_ID);


        String textStart = appointmentsStartDateTF.getText();
        String textEnd = appointmentsEndDateTF.getText();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        Integer Appointment_ID = Integer.valueOf(appointmentsAppIdTF.getText());
        String Title = appointmentsTitleTF.getText();
        String Description = appointmentsDescriptionTF.getText();
        String Location = appointmentsLocationTF.getText();
        String Type = appointmentsTypeTF.getText();
        LocalDateTime Start = LocalDateTime.parse(textStart, formatter);
        LocalDateTime End = LocalDateTime.parse(textEnd, formatter);
        int Customer_ID = Integer.parseInt(appointmentsCustomerIdTF.getText());
        Integer User_ID = Integer.valueOf(appointmentsUserIdTF.getText());
        LocalDateTime startToUTC = Appointments.toUTC(Start);
        LocalDateTime endToUTC = Appointments.toUTC(End);

        if (Appointments.appointmentOverlap(startToUTC, endToUTC, Customer_ID) && hasTextChanged(appointmentsStartDateTF)) {


            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Customer Overlap");
            alert.setContentText("This customer already has an appointment at that time.");
            alert.showAndWait();

        } else if (!Appointments.isWithinBusinessHours(Appointments.toEST(Start)) || !Appointments.isWithinBusinessHours(Appointments.toEST(End))) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Outside Business Hours");
            alert.setHeaderText(null);
            alert.setContentText("Please schedule appointment between 8:00 AM and 10:00 PM Eastern Standard Time.");
            alert.showAndWait();
        } else {

            selectedAppointment.setAppointment_ID(Appointment_ID);
            selectedAppointment.setTitle(Title);
            selectedAppointment.setLocation(Location);
            selectedAppointment.setDescription(Description);
            selectedAppointment.setContact_Name(Contact_Name);
            selectedAppointment.setType(Type);
            selectedAppointment.setStart(Start);
            selectedAppointment.setEnd(End);
            selectedAppointment.setCustomer_ID(Customer_ID);
            selectedAppointment.setUser_ID(User_ID);
            int selectedIndex = appointments.indexOf(selectedAppointment);
            appointments.set(selectedIndex, selectedAppointment);
            appointmentsTableView.setItems(appointments);

            AppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
            appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
            appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
            appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
            appointmentsContactsCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
            appointmentsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
            appointmentsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
            appointmentsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("End"));
            appointmentsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
            appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));

            try {
                PreparedStatement statement = conn.prepareStatement("UPDATE appointments SET Appointment_ID = ?, Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?,  Customer_ID = ?, User_ID = ?, Contact_ID = ?   WHERE Appointment_ID = ?");
                statement.setString(1, appointmentsAppIdTF.getText());
                statement.setString(2, appointmentsTitleTF.getText());
                statement.setString(3, appointmentsDescriptionTF.getText());
                statement.setString(4, appointmentsLocationTF.getText());
                statement.setString(5, appointmentsTypeTF.getText());
                LocalDateTime startDB = Appointments.toUTC(LocalDateTime.parse(textStart, formatter));
                LocalDateTime endDB = Appointments.toUTC(LocalDateTime.parse(textEnd, formatter));
                statement.setObject(6, startDB);
                statement.setObject(7, endDB);
                statement.setInt(8, Integer.parseInt(appointmentsCustomerIdTF.getText()));
                statement.setInt(9, Integer.parseInt(appointmentsUserIdTF.getText()));
                statement.setInt(10, selectedAppointment.getContact_ID());
                statement.setString(11, appointmentsAppIdTF.getText());
                statement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        }
    }


    @FXML
    public void onClickViewAppointments(ActionEvent event) throws IOException, SQLException {
        // appointmentsViewButton.setOnAction(e -> weekOrMonth.getToggles().forEach(t -> t.setSelected(false)));
        weekOrMonth.getToggles().forEach(t -> t.setSelected(false));

        String query = "SELECT * FROM appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID;";
        Statement statement = conn.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        int appointmentsTableViewNum = appointments.size();
        if (checkAppointmentsTableSize(appointmentsTableViewNum)) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Table is already populated");
            alert.setHeaderText(null);
            alert.setContentText("Table currently reflects the database.");
            alert.showAndWait();
        } else {
            while (resultSet.next()) {
                int Appointment_ID = resultSet.getInt("Appointment_ID");
                String Title = resultSet.getString("Title");
                String Description = resultSet.getString("Description");
                String Location = resultSet.getString("Location");
                String Contact_Name = resultSet.getString("Contact_Name");
                String Type = resultSet.getString("Type");
                LocalDateTime Start = resultSet.getObject("Start", LocalDateTime.class);
                LocalDateTime StartLocal = Appointments.toLocal(Start);
                //LocalDateTime Start = LocalDateTime.parse(resultSet.getString("Start"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                LocalDateTime End = resultSet.getObject("End", LocalDateTime.class);
                LocalDateTime EndLocal = Appointments.toLocal(End);
                int Customer_ID = resultSet.getInt("Customer_ID");
                int User_ID = resultSet.getInt("User_ID");


                Appointments appointment = new Appointments(Appointment_ID, Title, Description, Location, Contact_Name, Type, StartLocal, EndLocal, Customer_ID, User_ID);
                appointments.add(appointment);
            }


            appointmentsTableView.setItems(appointments);

            for (int i = 0; i < appointments.size(); i++) {
                Appointments currentAppointment = appointments.get(i);
                AppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
                appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
                appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
                appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
                appointmentsContactsCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
                appointmentsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
                appointmentsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
                appointmentsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("End"));
                appointmentsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
                appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));
            }


        }
    }



    ObservableList<String> contactNames = FXCollections.observableArrayList();
    ObservableList<Appointments> appointments = FXCollections.observableArrayList();

    private final DateTimeFormatter datetimeDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public Connection conn = JBDC.conn;


    /**
     *method that uses a lambda expression to add a listener to a textfield to see if the text entered has changed.
     * I created a method to check for appointment overlaps but it had the unintended consequences of preventing the editing of any of the parameters, not just the Start and end times.
     * I used the overlap method to set an alert if the times overlap with an existing appointment, I created and added this listener so I could use the && logical operator to ensure the time had been changed before displaying the warning.
     */
    public boolean hasTextChanged(TextField textField) {
        final StringProperty text = textField.textProperty();
        final String initialText = text.get();
        textField.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue) {
                final String currentText = text.get();
                if (!currentText.equals(initialText)) {
                    System.out.println("Text has changed");
                }
            }
        });
        return !text.get().equals(initialText);
    }


    /**
     * Second Lambda expression. I created a button to populate the appointments tableview with all the appointments currently in the database. This would populate the tableview as many times as you
     * clicked the view button though. So I added exception control using this method to compare the number of objects in the tableview to the number rows in the database.
     * Checks if the number of rows in the `appointments` table in the MySQL database is greater than or equal to the number of elements in the `appointmentsTableView` integer
     ** @param appointmentsTableViewNum an integer representing the number of rows in a table view
     * @return `true` if `appointmentsTableView` is greater than or equal to the number of rows in the `appointments` table in the MySQL database, and `false` otherwise.
     */
    public boolean checkAppointmentsTableSize(int appointmentsTableViewNum) {
        return ((Supplier<Boolean>) () -> {
            int rowsInDB = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM appointments")) {
                if (rs.next()) {
                    rowsInDB = rs.getInt(1);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return appointmentsTableViewNum >= rowsInDB;
        }).get();
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Appointments nameAppointments = new Appointments(appointmentsContactnameCombo);
        nameAppointments.addContactNames();




        try {

            String query = "SELECT * FROM appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID;";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);


            while (resultSet.next()) {
                int Appointment_ID = resultSet.getInt("Appointment_ID");
                String Title = resultSet.getString("Title");
                String Description = resultSet.getString("Description");
                String Location = resultSet.getString("Location");
                String Contact_Name = resultSet.getString("Contact_Name");
                String Type = resultSet.getString("Type");
                LocalDateTime Start = resultSet.getObject("Start", LocalDateTime.class);
                LocalDateTime StartLocal = Appointments.toLocal(Start);
                //LocalDateTime Start = LocalDateTime.parse(resultSet.getString("Start"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                LocalDateTime End= resultSet.getObject("End", LocalDateTime.class);
                LocalDateTime EndLocal = Appointments.toLocal(End);
                int Customer_ID = resultSet.getInt("Customer_ID");
                int User_ID = resultSet.getInt("User_ID");



                Appointments appointment = new Appointments(Appointment_ID, Title, Description, Location, Contact_Name, Type, StartLocal, EndLocal, Customer_ID, User_ID);
                appointments.add(appointment);
            }



            appointmentsTableView.setItems(appointments);

            for (int i = 0; i < appointments.size(); i++) {
                Appointments currentAppointment = appointments.get(i);
                AppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
                appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
                appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
                appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
                appointmentsContactsCol.setCellValueFactory(new PropertyValueFactory<>("Contact_Name"));
                appointmentsTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
                appointmentsStartDateCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
                appointmentsEndDateCol.setCellValueFactory(new PropertyValueFactory<>("End"));
                appointmentsCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
                appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}





