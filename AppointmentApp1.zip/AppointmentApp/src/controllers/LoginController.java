package controllers;

import helper.JBDC;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Date;
import java.util.function.Consumer;

import static models.Appointments.toLocal;

public class LoginController implements Initializable {

    public Label loginFormUserLocationLabel1;
    @FXML
    private Button loginCancelButton;

    @FXML
    private Button loginEnterButton;

    @FXML
    private Label loginFormUserLocationLabel;

    @FXML
    private Label loginPasswordLabel;

    @FXML
    private TextField loginPasswordTextfield;

    @FXML
    private Label loginUserNameLabel;

    @FXML
    private TextField loginUserNameTextfield;

    /**
     This method handles the user's validation when trying to log in. It checks if the password is valid and
     if it is, it directs the user to the Appointments or Customers screen. If the password is not valid,
     it displays an error message. Additionally, the login attempt, date and time, and success or failure
     is recorded in a text file "login_activity.txt".l
     @throws SQLException when an error occurs with the database connection
     @throws IOException when an error occurs with the file writer
     */
    @FXML
    void onCLickValidateUser(ActionEvent event) throws SQLException, IOException {
         String usernameEntered;
        LocalDateTime loginDateTime;
        boolean wasSuccessful;
        String userName = loginUserNameTextfield.getText();
        int userID = getUserID(userName, conn);
        String isItSuccsesful = "";




        if (isPasswordValid()) {
            isItSuccsesful = " successful.";
                hasUpcomingApp(userID, conn);
                Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/AppointmentsorCustomers.fxml")));
                Scene scene = new Scene(parent);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();


            } else {
            isItSuccsesful = " not successful.";
            Locale userLocale = Locale.getDefault();
            ResourceBundle resourceBundle = ResourceBundle.getBundle("helper/login", userLocale);
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle(resourceBundle.getString("invalidinput"));
                alert.setHeaderText(resourceBundle.getString("youhave"));
                alert.showAndWait();
            }

        FileWriter writer = new FileWriter("login_activity.txt", true);
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = formatter.format(date);

        String  IsItSuccsesful = isItSuccsesful;
        try {
            writer.write("Login Attempt at: " + formattedDate + " by " + userName + ", Attempt was" +  IsItSuccsesful + "\n");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    public static Connection conn = JBDC.conn;


    public boolean isPasswordValid() throws SQLException {


        String userName = loginUserNameTextfield.getText();
        String passWord = loginPasswordTextfield.getText();

        Statement stmt;
        try {
         stmt = conn.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }



        ResultSet rs = null;
         try {
        String sql = "SELECT * FROM users WHERE User_Name = '" + userName + "' AND Password = '" + passWord + "'";

        rs = stmt.executeQuery(sql);
        if (rs.next()) {

            return true;
        } else {

            return false;
        }


        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {

            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

public void setLabelByZoneId(){
    ZoneId userZoneId = ZoneId.systemDefault();
    loginFormUserLocationLabel.setText(String.valueOf(userZoneId));

}

    /**
     Updates the text of the given labels and buttons in the Login form to match the user's locale.
     */
public void updateLoginLabelsLanguageByUserLocale(Label loginUserNameLabel, Label loginPasswordLabel, Button loginEnterButton, Button loginCancelButton, Label loginFormUserLocationLabel1 ){
    Locale userLocale = Locale.getDefault();
    ResourceBundle resourceBundle = ResourceBundle.getBundle("helper/login", userLocale);
    loginUserNameLabel.setText(resourceBundle.getString("username"));
    loginPasswordLabel.setText(resourceBundle.getString("password"));
    loginEnterButton.setText(resourceBundle.getString("enter"));
    loginCancelButton.setText(resourceBundle.getString("cancel"));
    loginFormUserLocationLabel1.setText(resourceBundle.getString("userlocation"));


}

    /**
     A method that determines if a user has an upcoming appointment by checking if the user has a scheduled appointment in the next 15 minutes.
     @param userID the ID of the user to check for an upcoming appointment
     @param conn a database connection used to execute the query
     @return true if the user has an upcoming appointment, false otherwise
     */
    public static boolean hasUpcomingApp(int userID, Connection conn) {
        try {

            Calendar cal = Calendar.getInstance();
            TimeZone tz = TimeZone.getTimeZone("America/New_York");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            sdf.setTimeZone(tz);
            String currentTimeEST = sdf.format(cal.getTime());


            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            String currentTimeUTC = sdf.format(cal.getTime());


            String query = "SELECT Start, Appointment_ID FROM appointments WHERE User_ID = ? AND Start BETWEEN ? AND DATE_ADD(?, INTERVAL 15 MINUTE)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userID);
            statement.setString(2, currentTimeUTC);
            statement.setString(3, currentTimeUTC);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                String startTimeEST = result.getString("Start");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime utcTime = LocalDateTime.parse(startTimeEST, formatter);
                String localAppTime = String.valueOf(toLocal(utcTime));
                int appointmentID = result.getInt("Appointment_ID");

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setHeaderText("You have an appointment at " + localAppTime + " local time with Appointment ID: " + appointmentID);
                alert.showAndWait();
                return true;
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setHeaderText("You have no upcoming appointments.");
                alert.showAndWait();
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int getUserID(String userName, Connection conn) {
        try {
            String query = "SELECT User_ID FROM users WHERE User_Name = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, userName);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                int userID = result.getInt("User_ID");
                return userID;
            } else {
                throw new SQLException("User not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }




    private String usernameEntered;
    private LocalDateTime loginDateTime;
    private boolean wasSuccessful;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        setLabelByZoneId();
        updateLoginLabelsLanguageByUserLocale(loginUserNameLabel, loginPasswordLabel,  loginEnterButton,  loginCancelButton, loginFormUserLocationLabel1 );


    }


}















