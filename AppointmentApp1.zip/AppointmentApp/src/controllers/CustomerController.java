package controllers;

import helper.JBDC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.stage.Stage;
import models.Customer;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

import static models.Customer.customerHasApps;
import static models.Customer.divisionIdToDivision;

public class CustomerController implements Initializable {

    @FXML
    private Button customerAddButton;

    @FXML
    private Label customerAddressLabel;

    @FXML
    private ComboBox<String> customerCountryComboBox;

    @FXML
    private Button customerDeleteButton;

    @FXML
    private Label customerIdLabel;

    @FXML
    private Label customerNameLabel;

    @FXML
    public TextField customerNameTextField;

    @FXML
    private TextField customerAddressTextfield;

    @FXML
    private TextField customerPostalCodeTextfield;

    @FXML
    private TextField customerPhoneNumberTextfield;

    @FXML
    private Label customerPhoneNumberLabel;

    @FXML
    private Label customerPostalCodeLabel;

    @FXML
    private ComboBox<String> customerStateCombobox;


    @FXML
    private TableColumn<Customer, String> customerTableViewAdressCol;

    @FXML
    private TableView<Customer> customerTableview;

    @FXML
    private TableColumn<Customer, String> customerTableviewStateCol;

    @FXML
    private TableColumn<Customer, String> customerTableviewCountryCol;

    @FXML
    private TableColumn<Customer, Integer> customerTableviewIdCol;

    @FXML
    private TableColumn<Customer, String> customerTableviewNameCol;

    @FXML
    private TableColumn<Customer, String> customerTableviewPhoneCol;

    @FXML
    private TableColumn<Customer, String> customerTableviewPostalCodeCol;

    @FXML
    private Button customerUpdateButton;

    @FXML
    private TextField customerIdTextfield;

    @FXML
    public void onClickBack(ActionEvent event) throws IOException {

        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/AppointmentsorCustomers.fxml")));
        Scene scene = new Scene(parent);Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();stage.setScene(scene);stage.show();

    }


    /**
     Handles the event of selecting a country in the customer country combo box.
     Populates the customer state combo box with corresponding divisions of the selected country.
     @param event the event of selecting a country in the customer country combo box
     @throws SQLException if a database error occurs
     */
    @FXML
    void customerComboboxCountrySelect(ActionEvent event) throws SQLException {


        ObservableList<String> unitedStates = FXCollections.observableArrayList();
        ObservableList<String> canada = FXCollections.observableArrayList();
        ObservableList<String> unitedKingdom = FXCollections.observableArrayList();

        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Division, Division_ID FROM first_level_divisions");

        while (rs.next()) {
            String division = rs.getString("Division");
            int divisionId = rs.getInt("Division_ID");
            String selectedCountry = customerCountryComboBox.getSelectionModel().getSelectedItem();

            if (selectedCountry.equals("United States") && divisionId <= 54) {
                unitedStates.add(division);
                customerStateCombobox.setItems(unitedStates);

            } else if (selectedCountry.equals("Canada") && divisionId >= 60 && divisionId <= 72) {
                canada.add(division);
                customerStateCombobox.setItems(canada);
            } else if (selectedCountry.equals("United Kingdom") && divisionId > 100) {
                unitedKingdom.add(division);
                customerStateCombobox.setItems(unitedKingdom);
            }
        }
    }


    @FXML
    void customerStateComboboxSelect(ActionEvent event) throws SQLException {


    }

    /**
     Handles the event of clicking the "Save/Update" button
     Updates the selected customer in the customer tableview with the information in the text fields
     Saves the changes to the database
     @param actionEvent the event of clicking the "Save/Update" button
     @throws SQLException if a database error occurs
     */
    @FXML
    public void onClickSaveUpdate(ActionEvent actionEvent) throws SQLException {

        Customer selectedCustomer = customerTableview.getSelectionModel().getSelectedItem();
        Integer customerId = Integer.valueOf(customerIdTextfield.getText());
        String name = customerNameTextField.getText();
        String address = customerAddressTextfield.getText();
        String postalCode = customerPostalCodeTextfield.getText();
        String phoneNumber = customerPhoneNumberTextfield.getText();
        String country = customerCountryComboBox.getValue();
        String division = customerStateCombobox.getValue();
        Integer divisionId = Customer.divisionToDivisionId(division, conn);
        if (selectedCustomer != null) {
            selectedCustomer.setCustomerId(customerId);
            selectedCustomer.setName(name);
            selectedCustomer.setAddress(address);
            selectedCustomer.setPostalCode(postalCode);
            selectedCustomer.setPhoneNumber(phoneNumber);
            selectedCustomer.setCountry(country);
            selectedCustomer.setDivision(division);
            selectedCustomer.setDivisionId(divisionId);
            int selectedIndex = customers.indexOf(selectedCustomer);
            customers.set(selectedIndex, selectedCustomer);
            customerTableview.setItems(customers);
            try {
                PreparedStatement statement = conn.prepareStatement("UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Division_ID = ? WHERE customer_id = ?");
                statement.setString(1, customerNameTextField.getText());
                statement.setString(2, customerAddressTextfield.getText());
                statement.setString(3, customerPostalCodeTextfield.getText());
                statement.setString(4, customerPhoneNumberTextfield.getText());
                statement.setInt(5, divisionId);
                statement.setInt(6, selectedCustomer.getCustomerId());
                statement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


    }

    /**
     This method is called when the user clicks the "Add Customer" button. It adds a new customer to the customer table and updates the customer database with the new customer's information
     @param event the action event that triggers this method
     @throws SQLException if a database error occurs
     */
    @FXML
    void onClickAddCustomer(ActionEvent event) throws SQLException {

        PreparedStatement statement = conn.prepareStatement("SELECT MAX(Customer_ID) FROM customers", Statement.RETURN_GENERATED_KEYS);
        ResultSet resultSet = statement.executeQuery();
        resultSet.next();
        int generatedId = resultSet.getInt(1) + 1;


        Integer customerId = generatedId;
        String name = customerNameTextField.getText();
        String address = customerAddressTextfield.getText();
        String postalCode = customerPostalCodeTextfield.getText();
        String phoneNumber = customerPhoneNumberTextfield.getText();
        String country = customerCountryComboBox.getSelectionModel().getSelectedItem();
        String division = customerStateCombobox.getSelectionModel().getSelectedItem();

        Integer divisionId = Customer.divisionToDivisionId(division, conn);


        Customer newCustomer = new Customer(customerId, name, address, postalCode, phoneNumber, country, divisionId);
        newCustomer.setCustomerId(generatedId);
        newCustomer.setDivision(division);
        customerTableviewIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerTableviewNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        customerTableViewAdressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        customerTableviewPostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        customerTableviewPhoneCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        customerTableviewCountryCol.setCellValueFactory(new PropertyValueFactory<>(("country")));
        customerTableviewStateCol.setCellValueFactory(new PropertyValueFactory<>("division"));
        customerStateCombobox.getSelectionModel().select("division");
        customers.add(newCustomer);


        customerTableview.setItems(customers);

        Customer.addToCustomerDB(newCustomer, conn);

    }


    /**

     This method is an event handler for the delete customer button
     It deletes the selected customer from the database and the customer table view
     If the selected customer has existing appointments, the user will receive a warning message
     @param event the trigger for the method to be executed
     @throws SQLException if there is an error with the SQL database connection
     */
    @FXML
    void onClickCustomerDelete(ActionEvent event) throws SQLException {
        Connection conn = JBDC.conn;

        Customer selectedCustomer = customerTableview.getSelectionModel().getSelectedItem();
        Integer selectedID = selectedCustomer.getCustomerId();
        if (!customerHasApps(selectedID, conn)) {
        customers.remove(selectedCustomer);
        customerTableview.setItems(customers);
        // customerTableview.refresh();

            try {
                PreparedStatement statement = conn.prepareStatement("DELETE FROM customers WHERE Customer_ID = ?");
                statement.setInt(1, selectedCustomer.getCustomerId());
                statement.executeUpdate();
            }

             catch(SQLException e){
                e.printStackTrace();
            }
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setHeaderText("You have deleted a customer.");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setHeaderText("You cannot delete a customer that has existing appointments.");
            alert.showAndWait();
        }
    }






    /**
     * This method is called when the "Update Customer" button is clicked
     * It updates the customer information in the customer table and text fields
     * @param event the event that triggered this method.
     * @throws SQLException if there's an error executing the SQL statement
     */
    @FXML
    void onClickUpdateCustomer(ActionEvent event) throws SQLException {
        Customer selectedCustomer = customerTableview.getSelectionModel().getSelectedItem();
        if (selectedCustomer != null) {
            customerIdTextfield.setText(String.valueOf(selectedCustomer.getCustomerId()));
            customerNameTextField.setText(selectedCustomer.getName());
            customerAddressTextfield.setText(selectedCustomer.getAddress());
            customerPostalCodeTextfield.setText(selectedCustomer.getPostalCode());
            customerPhoneNumberTextfield.setText(selectedCustomer.getPhoneNumber());
            customerCountryComboBox.getSelectionModel().select(selectedCustomer.getCountry());
            customerStateCombobox.getSelectionModel().select( (divisionIdToDivision(String.valueOf(selectedCustomer.getDivisionId()), conn)));


        }
    }


    private final ObservableList<Customer> customers = FXCollections.observableArrayList();
    public Connection conn = JBDC.conn;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        customerCountryComboBox.setItems(FXCollections.observableArrayList("Canada", "United Kingdom", "United States"));


        try {

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customers");


            while (rs.next()) {

                Customer customer = new Customer(rs.getInt("Customer_ID"), rs.getString("Customer_Name"), rs.getString("Address"), rs.getString("Postal_Code"), rs.getString("Phone"), rs.getString("Division_ID"), rs.getInt("Division_ID"));
                String division = Customer.divisionIdToDivision(String.valueOf(customer.getDivisionId()), conn);
                customer.setDivision(division);
                if (Integer.parseInt(customer.getCountry()) <= 54) {
                    customer.setCountry("United States");
                    customer.setDivisionId(customer.getDivisionId());
                } else if (Integer.parseInt(customer.getCountry()) >= 60 && Integer.parseInt(customer.getCountry()) <= 72) {
                    customer.setCountry("Canada");
                    customer.setDivisionId(customer.getDivisionId());
                } else if (Integer.parseInt(customer.getCountry()) > 100) {
                    customer.setCountry("United Kingdom");
                    customer.setDivisionId(customer.getDivisionId());
                }
                customers.add(customer);
            }


            System.out.println("I got this far");
            customerTableviewIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
            customerTableviewNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
            customerTableViewAdressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
            customerTableviewPostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
            customerTableviewPhoneCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
            customerTableviewCountryCol.setCellValueFactory(new PropertyValueFactory<>("country"));
            customerTableviewStateCol.setCellValueFactory(new PropertyValueFactory<>("division"));

            customerTableview.setItems(customers);

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}







