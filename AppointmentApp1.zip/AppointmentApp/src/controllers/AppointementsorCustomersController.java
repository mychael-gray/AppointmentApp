package controllers;

      import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
      import javafx.fxml.FXMLLoader;
      import javafx.scene.Node;
      import javafx.scene.Parent;
      import javafx.scene.Scene;
      import javafx.scene.control.Alert;
      import javafx.scene.control.Button;
      import javafx.stage.Stage;
      import javafx.util.Callback;

      import java.io.IOException;
      import java.util.Objects;

public class AppointementsorCustomersController {
    Parent parent;
    @FXML
    private Button reportsButton;

    @FXML
    private Button appointmentsButton;

    @FXML
    private Button customersButton;


    /**
     *navigates to the Appointments page
     */
    @FXML
    void onClickNaviagteAppointments(ActionEvent event) throws IOException {
       Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/Appointments.fxml")));
       Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();




    }

    /**
     *navigates to the Reports page
     */
    @FXML
    void onClickNavigateReports(ActionEvent event) throws IOException {
            Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/Reports.fxml")));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
    }

    /**
     *navigates to the Customers page
     */
    @FXML
    void onClickNavigateCustomersPage(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/Customer.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

}

