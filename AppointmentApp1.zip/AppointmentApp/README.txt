Application: Global Scheduling Application

Purpose: Assist client with scheduling customer appointments from different locations across the world. Time zones are automatically converted for relevant purposes and displayed to the user in their local time zone.

Author:Mychael Gray
       mgra126@wgu.edu
       Global Scheduling Application 2.0
       2/1/2023

IDE: IntelliJ IDEA Community Edition 2021.1.3 x64
JDK: Java SE 17.0.1 compatable with JavaFX-SDK-17.0.1
Driver Version: mysql-connector-java-8.0.25

Directions:

    1. A login page will prompt you to enter a username and login. Enter your credentials the hit the enter button.

    2. When you successfully login you will be directed to a page where you can select to navigate to the Customers, Appointments, or Reports page. Select your relevant page.

    3. In the customer page you are able to add, delete and save customers. To update a customer select the customer in the tableview and select the update button. The data will be populated to the relevant textfields. Make your edits then hit the Save Update button
    to save the updates to the textfield and database.

    4. In the Appointments page you are able to add, delete and save appointments. To update a appointment select the appointment in the tableview and select the update button. The data will be populated to the relevant textfields. Make your edits then hit the Save Update button
        to save the updates to the textfield and database.

    4.a. In the appointments section there are two radio buttons, weekly and monthly. Weekly will show all appointments in the upcoming week and the monthly will do the same for the upcoming month.
    If you wish to view all the appoinments in the data  hit the View button. To clear the table hit the clear table button.

     5. In the reports section you have the option to search the appoitnments by month and type. First select the comobobox entitled type and then select the month in the month combobox. All appointments of that type and month will populate in the tableview below.

     6. Also in the reports sections is a tableview that will show the scheduale for the contact selected in the contact tableview.

     7. There is a counter for the number of customers from each country in the reports page as well. This auto-fills and does not require your interaction.


 Added Report: I added a report that counts the numbers of customers from each country. This report is auto-implemented on scene change and changes the labels for each country numbers by querying the database by Appointment_ID, Customer_ID and Division_ID.